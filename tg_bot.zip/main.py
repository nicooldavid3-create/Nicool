import telebot

TOKEN = "8224111944:AAE4g7NuBmLnRMY4rdyRORND3E4ScjkS47w"
ADMIN_USERNAME = "nicooldavid"

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "Hello! This is your bot.")

@bot.message_handler(func=lambda m: m.from_user.username == ADMIN_USERNAME)
def admin_message(message):
    bot.reply_to(message, "Hello Admin!")

@bot.message_handler(func=lambda m: True)
def echo_all(message):
    bot.reply_to(message, message.text)

bot.infinity_polling()
